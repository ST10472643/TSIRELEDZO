package registration;

import javax.swing.JOptionPane;

public class Registration {
    private static String firstName;
    private static String lastName;
    private static String password;
    private static String username;
    private static String phoneNumber;

    // Getters and setters
    public static void setFirstName(String name) { firstName = name; }
    public static String getFirstName() { return firstName; }

    public static void setLastName(String surname) { lastName = surname; }
    public static String getLastName() { return lastName; }

    public static void setUserName(String userName) { username = userName; }
    public static String getUserName() { return username; }

    public static void setPassword(String pw) { password = pw; }
    public static String getPassword() { return password; }

    public static void setPhoneNumber(String phone) { phoneNumber = phone; }
    public static String getPhoneNumber() { return phoneNumber; }

    public static void main(String[] args) {
        setFirstName(JOptionPane.showInputDialog(null, "Please enter your first name"));
        setLastName(JOptionPane.showInputDialog(null, "Please enter your last name"));

        // Username
        String inputUsername;
        do {
            inputUsername = JOptionPane.showInputDialog(null,
                "Please enter your username (must be ≤5 characters and contain '_'):");
            if (!login.checkUserName(inputUsername)) {
                JOptionPane.showMessageDialog(null,
                    "Incorrect username format!\nUsername must be:\n- No more than 5 characters long\n- Contain an underscore (_)");
            }
        } while (!login.checkUserName(inputUsername));
        setUserName(inputUsername);

        // Password
        String inputPassword;
        do {
            inputPassword = JOptionPane.showInputDialog(null,
                "Please enter your password (must be ≥8 characters with:\n- At least 1 capital letter\n- At least 1 number\n- At least 1 special character):");
            if (!login.checkPasswordComplexity(inputPassword)) {
                JOptionPane.showMessageDialog(null,
                    "Password incorrectly formatted!\nPassword must contain:\n- At least 8 characters\n- At least 1 capital letter\n- At least 1 number\n- At least 1 special character");
            }
        } while (!login.checkPasswordComplexity(inputPassword));
        setPassword(inputPassword);

        // Phone number
        String inputPhone;
        do {
            inputPhone = JOptionPane.showInputDialog(null,
                "Please enter your phone number (must start with 0 followed by 9 digits):");
            if (!login.checkPhoneNumber(inputPhone)) {
                JOptionPane.showMessageDialog(null,
                    "Phone number incorrect!\nPhone number must:\n- Start with 0\n- Be followed by 9 digits\n- Example: 0831234567");
            }
        } while (!login.checkPhoneNumber(inputPhone));
        setPhoneNumber(inputPhone);

       
        login login = new login();

        // Register
        JOptionPane.showMessageDialog(null,
            login.registerUser(getUserName(), getPassword(), getPhoneNumber()));

        // Login
        boolean regStatus = login.loginUser(
            login.checkUserName(getUserName()),
            login.checkPasswordComplexity(getPassword())
        );

        JOptionPane.showMessageDialog(null,
            login.returnLoginStatus(regStatus, getFirstName(), getLastName()));
    }
}